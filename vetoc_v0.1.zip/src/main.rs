use std::env;
use std::fs;
use std::process::{Command, ExitCode};

use vetoc::compiler::{generate_c, Parser};
use vetoc::lexer::Lexer;

fn main() -> ExitCode {
    let args: Vec<String> = env::args().collect();

    if args.len() < 2 {
        eprintln!("Использование: vetoc <файл.vt>");
        return ExitCode::from(1);
    }

    let source = match fs::read_to_string(&args[1]) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("[VETO] не могу прочитать {}: {}", args[1], e);
            return ExitCode::from(1);
        }
    };

    // 1. Токенизация
    let mut lexer = Lexer::new(&source);
    let tokens = lexer.tokenize();

    // 2. Парсинг + проверка диапазонов
    let mut parser = Parser::new(tokens);
    let ast = parser.parse_main();

    // 3. Генерация C-кода (внутри — вызов Инквизитора на prove, под фичей)
    let c_code = generate_c(&ast, &source);

    // Системная временная папка (работает и в Windows AppData\Local\Temp, и в Linux /tmp)
    let temp_dir = env::temp_dir();
    let temp_c = temp_dir.join("veto_out.c");
    if let Err(e) = fs::write(&temp_c, c_code) {
        eprintln!("[VETO] не могу записать {}: {}", temp_c.display(), e);
        return ExitCode::from(1);
    }

    let out_bin = if cfg!(windows) {
        "veto_app.exe"
    } else {
        "veto_app"
    };

    // 4. Вызов gcc
    let gcc_result = Command::new("gcc")
        .args([
            temp_c.to_str().unwrap(),
            "-O3",
            "-march=native",
            "-fno-stack-protector",
            "-lSDL2",
            "-o",
            out_bin,
        ])
        .status();

    match gcc_result {
        Ok(status) if status.success() => {
            println!("[SUCCESS]: собрано в ./{} (0 проверок в рантайме)", out_bin);
            ExitCode::SUCCESS
        }
        Ok(status) => {
            eprintln!("[VETO] gcc завершился с кодом {:?}", status.code());
            ExitCode::from(1)
        }
        Err(e) => {
            eprintln!("[VETO] не могу запустить gcc: {}", e);
            ExitCode::from(1)
        }
    }
}
